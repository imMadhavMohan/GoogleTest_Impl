#pragma once
#include <algorithm>
#include <vector>
#include <iostream>
#include <math.h>
#include <stdexcept>

using namespace std;

class Account{
    private:
        double balance;
        int userid;
    public:
        Account(int id);
        void deposit(double amnt);
        double getBalance();
        void withdraw(double amnt);
        void transfer(Account* user, double amnt);
};