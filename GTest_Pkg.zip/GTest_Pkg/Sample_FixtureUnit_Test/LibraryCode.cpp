#include "LibraryCode.hpp"

Account::Account(int id):userid(id){
    cout<<"Acc created & userid: "<<id<<endl;
}

void Account::deposit(double amnt){    
    balance +=amnt; 
}

double Account::getBalance(){
    return balance;
}

void Account::transfer(Account* User, double amnt){
    if(balance<amnt)
        throw runtime_error("Insufficient Balance can't Tx\n");
    balance-=amnt;
    User->balance+=amnt;
}

void Account::withdraw(double amnt){
    if(balance<amnt)
        throw runtime_error("Insufficient Balance can't withdraw\n");
    balance-=amnt;
}