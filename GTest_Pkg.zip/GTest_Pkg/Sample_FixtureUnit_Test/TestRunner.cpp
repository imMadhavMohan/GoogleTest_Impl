#include "LibraryCode.hpp"
#include <gtest/gtest.h>

class AccountTestFixture: public ::testing::Test{
    protected:
        Account* user;
    
        AccountTestFixture(){
            cout<<"Fixture's Contructor\n";
        }
        void SetUp() override{ 
            cout<<"SetUp called\n"<<endl;
            user = new Account(1);           
            cout<<"Balance is: "<<user->getBalance()<<endl;
            user->deposit(240.5);      
        }
        void TearDown() override{
            cout<<"TearDown called\n";
            free(user); // delete user
        }

        static void SetUpTestSuite() {
            cout<<"***Run at the beginning of all TCs***\n";
        }

        static void TearDownTestSuite() {
            cout<<"***Run at the end of all TCs***\n";
        }
        
        ~AccountTestFixture(){
            cout<<"Fixture's Destructor\n";
        }
};

// unitTest-1 with test_Fixture
TEST_F(AccountTestFixture, NegativeBalance){
    // Account* user = new Account(1);
    // cout<<"Balance is: "<<user->getBalance()<<endl;
    // user->deposit(240.5);    

    cout<<"Balance is: "<<user->getBalance()<<endl;
    ASSERT_THROW(user->withdraw(250.5), runtime_error);
}

// unitTest-2 
TEST_F(AccountTestFixture, BalanceTx){
    // Account* user = new Account(1);
    // cout<<"Balance is: "<<user->getBalance()<<endl;
    // user->deposit(240.5);  
    // cout<<"Balance is: "<<user->getBalance()<<endl;

    Account* user2 = new Account(2);
    ASSERT_THROW(user->transfer(user2, 250.5), runtime_error);
}

// unitTest-3 
TEST(TestAccount, DepositTest){
    Account* user = new Account(1);
    cout<<"\nNot from Fixtures \nBalance is: "<<user->getBalance()<<endl;
    user->deposit(240.5);  
    cout<<"Balance is: "<<user->getBalance()<<endl;    

    ASSERT_NO_THROW(user->getBalance());
}

int main(int argc ,  char** argv){
    testing::InitGoogleTest(&argc, argv);
    cout<<"TestRunner Triggers: \n";
    return RUN_ALL_TESTS();
}