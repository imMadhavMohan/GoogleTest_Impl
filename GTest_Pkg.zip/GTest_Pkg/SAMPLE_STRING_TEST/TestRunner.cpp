#include "LibraryCode.hpp"
#include <gtest/gtest.h>


// unitTest-1
TEST(TestUpperStr1, ToUpperStr){
    char str[] = "Hello World!";
    // ACT
    toUpperStr(str);

    if(str == "HELLO WORLD!") // comparison of pointers
        cout<<"Same Addr\n";
    else 
        cout<<"Different Addr\n";

    // Content compaarison        
    if(strcmp(str,"HELLO WORLD!") == 0){
        cout<<"STRINGS ARE EQUAL\n";
    }else{  // Assert      
        // ASSERT_EQ("HELLO WORLD!",str); // Fatal Assertion & here we're comparing the Addr so it'll fail
        ASSERT_EQ(strcmp(str,"HELLO WORLD!"),0);
    }
}

// unitTest-2
TEST(TestUpperStr2, ToUpperStr){
    char str[] = "Hello World!";
    // ACT
    toUpperStr(str);

    // Assert for c-string     
    // ASSERT_EQ("HELLO WORLD!",str); // Fatal Assertion & here we're comparing the Addr so it'll fail
    // ASSERT_EQ(strcmp(str,"HELLO WORLD!"),0);
    ASSERT_STREQ("HELLO WORLD!",str); 
}

// unitTest-3
TEST(TestUpperStr3, ToUpperStr){
    char str[] = "Hello World!";
    // ACT
    toUpperStr(str);

    // Assert for std::string    
    string wstr{str};
    ASSERT_EQ("HELLO WORLD!",wstr); 
}

int main(int argc ,  char** argv){
    testing::InitGoogleTest(&argc, argv);
    cout<<"TestRunner Triggers: \n";
    return RUN_ALL_TESTS();
}