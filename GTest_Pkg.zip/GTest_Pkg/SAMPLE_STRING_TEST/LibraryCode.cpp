#include "LibraryCode.hpp"

void toUpperStr(char* str){
    for(int i=0;i<strlen(str);i++){
        str[i] = toupper(str[i]); // convert
    }
}