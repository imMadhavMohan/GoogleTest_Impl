#pragma once
#include <algorithm>
#include <vector>
#include <iostream>
#include <string.h>


using namespace std;

void toUpperStr(char* str); 