#include "LibraryCode.hpp"

Calculator::Calculator(int a,int b):a(a),b(b){
    cout<<"GotNums a & b\n";
}

Calculator::Calculator() = default;

int Calculator::add(){
    return a+b;
}

int Calculator::subtract(){
    if(a<b) 
        throw invalid_argument("b is LT a\n");
    return a-b;
}

int Calculator::divide(){
    if(b==0)
        throw invalid_argument("b is 0\n");
    return a/b;
}
