#pragma once
#include <algorithm>
#include <vector>
#include <iostream>
#include <math.h>
#include <stdexcept>

using namespace std;

class Calculator {
public:
    Calculator(int a,int b);
    Calculator();
    
    int add();
        
    int subtract();

    int multiply();

    int divide();

private:
    int a,b;
};