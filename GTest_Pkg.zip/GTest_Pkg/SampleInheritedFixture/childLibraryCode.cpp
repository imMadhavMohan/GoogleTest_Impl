#include "childLibraryCode.hpp"

AdvCalculator::AdvCalculator(double lg):lg(lg){    
    std::cout<<"Got num for log\n";
}

AdvCalculator::AdvCalculator(int a, int b):Calculator(a,b){    
    std::cout<<"Got num for log\n";
}

AdvCalculator::AdvCalculator() = default;


double AdvCalculator::findLoge(){
    return log10(lg);
}