#include "LibraryCode.hpp"
#include "math.h"

class AdvCalculator: public Calculator{
    double lg;
    public:
        AdvCalculator();
        AdvCalculator(int a,int b);
        AdvCalculator(double lg);
        double findLoge();
};