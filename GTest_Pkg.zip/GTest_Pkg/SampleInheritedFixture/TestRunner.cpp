#include "LibraryCode.hpp"
#include "childLibraryCode.hpp"
#include <gtest/gtest.h>

class CalculatorTestFixture: public ::testing::Test{
    protected:
        Calculator* Cal;
    
        CalculatorTestFixture(){
            cout<<"Fixture's Contructor\n";
        }
        void SetUp() override{ 
            cout<<"SetUp called\n"<<endl;
            Cal = new Calculator(18,9);                       
        }
        void TearDown() override{
            cout<<"TearDown called\n";
            free(Cal); // delete user
        }

        static void SetUpTestSuite() {
            cout<<"***Run at the beginning of all TCs***\n";
        }

        static void TearDownTestSuite() {
            cout<<"***Run at the end of all TCs***\n";
        }
        
        ~CalculatorTestFixture(){
            cout<<"Fixture's Destructor\n";
        }
};

// Child Fixture class
class AdvCalculatorTestFixture: public CalculatorTestFixture{            
    protected:
        AdvCalculator* AdvCal;
        void SetUp(){
           CalculatorTestFixture::SetUp();  
           AdvCal = new AdvCalculator(100);
           cout<<"ChildFixture SetUp\n";
        }
        void TearDown(){
            CalculatorTestFixture::TearDown();
            cout<<"ChildFixture tearDown\n";
            delete AdvCal;
        }
};

// unitTest-1 with test_Fixture
TEST_F(CalculatorTestFixture, ADDTest){
    int x = Cal->add();
    ASSERT_EQ(27,x);
}

// unitTest-2 
TEST_F(CalculatorTestFixture, SUBTest){
    ASSERT_THROW(Cal->subtract(), invalid_argument);
}

// unitTest-3 
TEST_F(AdvCalculatorTestFixture, Logtest){
    ASSERT_EQ(AdvCal->findLoge(), 2);
    ASSERT_NO_THROW(Cal->divide());
}

// unitTest-4
TEST(AdvCalculatorTest, Logtest1){
    AdvCalculator* AdvCal = new AdvCalculator(1000);
    ASSERT_EQ(AdvCal->findLoge(), 3);
}

int main(int argc ,  char** argv){
    testing::InitGoogleTest(&argc, argv);
    cout<<"TestRunner Triggers: \n";
    return RUN_ALL_TESTS();
}