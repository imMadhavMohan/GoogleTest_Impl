#pragma once
#include <algorithm>
#include <vector>
#include <iostream>

using namespace std;


bool isPositive(int x);

int cntPositive(std::vector<int> const& arr);