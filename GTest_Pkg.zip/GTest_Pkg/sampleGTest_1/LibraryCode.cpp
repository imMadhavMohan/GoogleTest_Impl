#include "LibraryCode.hpp"

bool isPositive(int x){
    return x >= 0;
}

int cntPositive(std::vector<int> const& arr){
    return std::count_if(arr.begin(), arr.end(), isPositive);
}