#include "LibraryCode.hpp"
#include <gtest/gtest.h>


// unitTest-1
TEST(TestCountPositiveNumm, BasicTest){
    vector<int> arr{1,-2,3,-4,-6,7};
    int cnt = cntPositive(arr);

    // Assert
    ASSERT_EQ(3,3);
}

// unitTest-2
TEST(TestCountPositiveNum, EmptyVector){
    vector<int> arr{};
    int cnt = cntPositive(arr);

    // Assert
    ASSERT_EQ(0, cnt);
}

// unitTest-3
TEST(TestCountPositiveNum, AllNegative){
    vector<int> arr{1,-2,-3,-4,-5};
    int cnt = cntPositive(arr);

    // Assert
    ASSERT_NE(4, cnt);
}

int main(int argc ,  char** argv){
    testing::InitGoogleTest(&argc, argv);
    cout<<"TestRunner Triggers: \n";
    return RUN_ALL_TESTS();
}