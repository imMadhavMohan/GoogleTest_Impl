#include "../includes/addnum.h"
#include <memory>
#include "../includes/multiplyLib.hpp"  
// #include <gtest/gtest.h>

int addNum(int a,int b){
    return a+b;
}

// TEST(TestSample, TestAdd){ // pretend as t is a actual app
//     ASSERT_EQ(18, addNum(9,9));
// }

int main(int argc, char **argv){
    //testing::InitGoogleTest(&argc, argv);
    shared_ptr<AddNum> addNum = make_shared<AddNum>();
    addNum->setNum(9,9);
    cout<<"Sum of Two nums: "<<addNum->getSum()<<endl;
    cout<<"Mul of twoNums: "<<multiplyNum(9,9)<<endl;
    //return RUN_ALL_TESTS();
    return 0;
}

// gedit to open the linux text editor