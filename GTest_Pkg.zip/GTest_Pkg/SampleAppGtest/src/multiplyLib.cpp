#include "../includes/multiplyLib.hpp"

int multiplyNum(int a, int b){
    return a*b;
}