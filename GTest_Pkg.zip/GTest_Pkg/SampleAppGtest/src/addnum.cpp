#include "../includes/addnum.h"

AddNum::AddNum(){
    cout<<"Obj Created\n";
}

void AddNum::setNum(int a,int b){
    this->a = a ; 
    this->b = b;
}

int AddNum::getSum(){
    return a+b;
}