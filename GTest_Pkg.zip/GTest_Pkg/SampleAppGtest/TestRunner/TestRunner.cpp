#include <iostream>
#include "../includes/multiplyLib.hpp"
#include <gtest/gtest.h>

TEST(TsetSample, TestMultiplication){
    ASSERT_EQ(4,multiplyNum(2,2));
}

int main(int argc, char** argv){
    testing::InitGoogleTest(&argc,argv);
    std::cout<<"TestRunner with GTest\n";
    return RUN_ALL_TESTS();
}