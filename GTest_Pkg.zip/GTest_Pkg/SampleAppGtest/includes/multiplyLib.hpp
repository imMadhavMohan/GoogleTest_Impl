#pragma once

int multiplyNum(int a, int b);