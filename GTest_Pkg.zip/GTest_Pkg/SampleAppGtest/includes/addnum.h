#ifndef ADDNUM_H
#define ADDNUM_H

#include <iostream>
using namespace std;

class AddNum{
    private:
        int a,b;
    public:
        AddNum();
        void setNum(int a,int b);
        int getSum();
};

#endif


