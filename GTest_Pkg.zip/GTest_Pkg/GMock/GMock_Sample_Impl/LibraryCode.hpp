#pragma once
#include <algorithm>
#include <vector>
#include <iostream>
#include <math.h>
#include <stdexcept>

using namespace std;

class Calculator {
public:    
    Calculator();

    float getSum(float x, int y) const;

    float getMul(float x, int y);

    float getSub(float x, int y);

    float getDiv(float x, float y) const;

    float getLog(float x) const;
private:
    int num;
};