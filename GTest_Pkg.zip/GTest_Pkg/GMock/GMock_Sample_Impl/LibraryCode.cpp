#include "LibraryCode.hpp"

Calculator::Calculator (){
    cout<<"Constructor called\n";
}

float Calculator::getSum(float x, int y) const {
    return x+y;
}

float Calculator::getMul(float x, int y){
    return x*y;
}

float Calculator::getSub(float x, int y){
    if(x<=y)
        throw invalid_argument("Inavllid arg used\n");
    return (x-y);
}

float Calculator::getDiv(float x, float y) const {
    if (y == 0) {
        throw std::invalid_argument("Invalid argument used: Division by zero");
    }
    return x / y;
}

float Calculator::getLog(float x) const{
    return log10(x);
}
