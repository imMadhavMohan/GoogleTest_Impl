#include "LibraryCode.hpp"
#include <gtest/gtest.h>
#include <gmock/gmock.h>

class AdvCal: public Calculator{
    public:
        AdvCal() = default;
         
        MOCK_METHOD(float, getSum, (float a,int b), (const)); // 1st Mock method
        MOCK_METHOD(float, getMul, (float a,int b), (const)); // 2nd Mock method
        MOCK_METHOD(float, getLog, (float a), (const)); // 3rd Mock method 
        MOCK_METHOD(float, getDiv, (float a,float b), (const)); // 4th Mock method
        MOCK_METHOD(float, getSub, (float a,float b), (const)); // 5th Mock method     
};

class MockCal: public ::testing::Test{
    protected:
        AdvCal mobj;                
};

TEST_F(MockCal, sumTest){
    // Calling default Time = 1 call
    EXPECT_CALL(mobj, getSum(2.03f, 5)).WillOnce(::testing::Return(7.03f)); 

    // Call it to pas TCs
    ASSERT_EQ(mobj.getSum(2.03f,5), 7.03f);
}

TEST_F(MockCal, mulTest){
    // Calling!!.Times(5)!!
    EXPECT_CALL(mobj, getMul(2.03f, 5)).WillOnce(::testing::Return(10.15f)); 

    
    // Call it to pas TCs
    ASSERT_FLOAT_EQ(mobj.getMul(2.03f,5), 10.15f);
}

TEST_F(MockCal, logTest){
    // Calling!!.Times(5)!!
    EXPECT_CALL(mobj, getLog(1000)).WillOnce(::testing::Return(3)); 
    
    // Call it to pas TCs
    ASSERT_EQ(mobj.getLog(1000), 3);
}

TEST_F(MockCal, divTest){
    // Calling!!.Times(5)!!
    EXPECT_CALL(mobj, getDiv(1000, 200)).Times(::testing::AtLeast(1)).WillOnce(::testing::Return(5));
    
    // Call it to pas TCs
    ASSERT_EQ(mobj.getDiv(1000,200), 5);
}

TEST_F(MockCal, seqTest){
    ::testing::InSequence seq; // Forcing Sequence
    // 1st call
    EXPECT_CALL(mobj, getDiv(1000, 200)).Times(::testing::AtLeast(1)).WillOnce(::testing::Return(5));

    // 2nd call
    EXPECT_CALL(mobj, getSub(1000, 200)).Times(::testing::AtLeast(1)).WillOnce(::testing::Return(800));

    // 3rd call
    EXPECT_CALL(mobj, getMul(1000, 200)).Times(::testing::AtLeast(1)).WillOnce(::testing::Return(200000));

    // Call it to pas TCs
    ASSERT_EQ(mobj.getDiv(1000,200), 5);
    ASSERT_EQ(mobj.getSub(1000,200), 800);
    ASSERT_EQ(mobj.getMul(1000,200), 200000);
}

TEST_F(MockCal, RetiresOnSaturationTest) {
    // Create a sequence to enforce call order
    ::testing::InSequence seq;

    // Setting up expectations
    EXPECT_CALL(mobj, getSum(2.0f, 3)) // First call
        .Times(::testing::AtLeast(2)) // Allow at least two calls
        .WillRepeatedly(::testing::Return(5.0f)); // Always return 5.0f

    EXPECT_CALL(mobj, getMul(2.0f, 3)) // Second call
        .Times(1)
        .WillOnce(::testing::Return(6.0f));

    // Set up getLog with RetiresOnSaturation
    EXPECT_CALL(mobj, getLog(1000)) // Third call
        .Times(::testing::AtMost(5))
        .WillOnce(::testing::Return(3.0f))
        .RetiresOnSaturation(); // Retire this expectation after being satisfied

    EXPECT_CALL(mobj, getDiv(10.0f, 2.0f)) // Fourth call
        .Times(1)
        .WillOnce(::testing::Return(5.0f));

    // Call the methods in the expected order
    ASSERT_EQ(mobj.getSum(2.0f, 3), 5.0f); // First call to getSum
    ASSERT_EQ(mobj.getSum(2.0f, 3), 5.0f); // Second call to getSum
    ASSERT_EQ(mobj.getMul(2.0f, 3), 6.0f);

    // Call getLog twice, the second call won't be checked against the expectation
    ASSERT_EQ(mobj.getLog(1000), 3.0f); // First call to getLog
    ASSERT_EQ(mobj.getLog(1000), 3.0f); // Second call, this won't fail the test

    // Ensure getDiv is called once
    ASSERT_EQ(mobj.getDiv(10.0f, 2.0f), 5.0f); // This line was missing, added here
}


//Matcher
TEST_F(MockCal, matcherTest){
    // Calling!!.Times(5)!!
    EXPECT_CALL(mobj, getDiv(::testing::Gt(999), ::testing::Le(200))).WillOnce(::testing::Return(5));
    
    // Call it to pas TCs
    ASSERT_EQ(mobj.getDiv(1000,200), 5);
}

TEST_F(MockCal, matcherTest1){
    // Calling!!.Times(5)!!
    EXPECT_CALL(mobj, getDiv(::testing::Gt(999), ::testing::Le(200))).WillOnce(::testing::Return(5));
    EXPECT_CALL(mobj, getSum(::testing::_, ::testing::_)).WillOnce(::testing::Return(1200.0f));
    // Call it to pas TCs
    ASSERT_EQ(mobj.getDiv(1000,200), 5);
    ASSERT_EQ(mobj.getSum(1000,200), 1200);
}

int main(int argc ,  char** argv){
    testing::InitGoogleTest(&argc, argv);
    cout<<"TestRunner Triggers: \n";
    return RUN_ALL_TESTS();
}