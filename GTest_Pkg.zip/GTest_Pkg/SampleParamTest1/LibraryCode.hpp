#pragma once
#include <algorithm>
#include <vector>
#include <iostream>
#include <math.h>
#include <stdexcept>

using namespace std;

class CheckNumType {
public:    
    CheckNumType();
    
    void setNum(int num);

    int getNum();

    bool isEven();

    bool isOdd();
private:
    int num;
};