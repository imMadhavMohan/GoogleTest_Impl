#include "LibraryCode.hpp"
#include <gtest/gtest.h>

class CheckNumTypeTest: public ::testing::TestWithParam<tuple<int,bool>>{
    protected:        
        CheckNumType* mCheckNum;
        CheckNumTypeTest(){
            cout<<"ACheckNumTypeTestFixure constru\n";
        }
        void SetUp() override{ 
            CheckNumType* mCheckNum = new CheckNumType();
            cout<<"SetUp is Ready\n";            
        }
        void TearDown() override{
            cout<<"CleanUp is done Ready\n";    
        }
        ~CheckNumTypeTest(){
            cout<<"AgeValidTestFixure Destru\n";
            free(mCheckNum);
        }
};

// unitTest-1 
TEST_P(CheckNumTypeTest, evenNumCheck){
      mCheckNum->setNum(get<0>(GetParam()));
      ASSERT_EQ(mCheckNum->isEven(), get<1>(GetParam()));
}

// unitTest-2
// TEST_P(CheckNumTypeTest, oddNumCheck){
//       mCheckNum->setNum(get<0>(GetParam()));
//       ASSERT_EQ(mCheckNum->isOdd(), get<1>(GetParam()));
// }

// Set of 4 test cases : All Ran on same Fixture so total cnt = 16
// INSTANTIATE_TEST_SUITE_P(AddOddTestCases, CheckNumTypeTest, testing::Values(
//                                                             make_tuple(1,true),
//                                                             make_tuple(3,true),
//                                                             make_tuple(2,false),
//                                                             make_tuple(4,false)
// ));

// Set of 4 test cases
INSTANTIATE_TEST_SUITE_P(AddEvenTestCases, CheckNumTypeTest, testing::Values(
                                                            make_tuple(1,false),
                                                            make_tuple(3,false),
                                                            make_tuple(2,true),
                                                            make_tuple(4,true)
));



// unitTest-2
// TEST(AdvCalculatorTest, Logtest1){
//     AdvCalculator* AdvCal = new AdvCalculator(1000);
//     ASSERT_EQ(AdvCal->findLoge(), 3);
// }

int main(int argc ,  char** argv){
    testing::InitGoogleTest(&argc, argv);
    cout<<"TestRunner Triggers: \n";
    return RUN_ALL_TESTS();
}