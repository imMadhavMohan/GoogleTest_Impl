#include "LibraryCode.hpp"

CheckNumType ::CheckNumType (){
    cout<<"Constructor called\n";
}

void CheckNumType::setNum(int num){
    this->num = num;
}

bool CheckNumType::isEven(){
    return (num&1)?0:1;
}

bool CheckNumType::isOdd(){
    return (num&1)?1:0;
}

int CheckNumType::getNum(){
    return num;
}