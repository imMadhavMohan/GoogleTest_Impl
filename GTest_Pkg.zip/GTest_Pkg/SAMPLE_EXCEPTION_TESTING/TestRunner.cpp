#include "LibraryCode.hpp"
#include <gtest/gtest.h>


// unitTest-1 check whether fun throw error on invalid o/p
TEST(TestSqrNum, NegativeNumtest){
    double num = -81;

    ASSERT_ANY_THROW(sqrtNum(num));
}

// unitTest-2
TEST(TestSqrNum, NegativeNumtest1){
    double num = -81;

    ASSERT_THROW(sqrtNum(num), std::runtime_error); // Specific Exception is expected
}

// unitTest-3
TEST(TestSqrNum, PositiveNumtest){
    double num = 81;

    ASSERT_NO_THROW(sqrtNum(num)); // Exception isn't expected
}

// unitTest-4
TEST(TestSqrNum, EvenNum){
    double num = 81;

    ASSERT_THROW(checkEven(num),const char*); // Exception expected of type c-string
}

// unitTest-5
TEST(TestSqrNum, OddNum){
    double num = 81;

    ASSERT_THROW(checkOdd(num),invalid_argument); // Exception expected of type c-string
}

int main(int argc ,  char** argv){
    testing::InitGoogleTest(&argc, argv);
    cout<<"TestRunner Triggers: \n";
    return RUN_ALL_TESTS();
}