#pragma once
#include <algorithm>
#include <vector>
#include <iostream>
#include <math.h>
#include <stdexcept>

using namespace std;

double sqrtNum(double num);

int checkEven(int num);

int checkOdd(int num);