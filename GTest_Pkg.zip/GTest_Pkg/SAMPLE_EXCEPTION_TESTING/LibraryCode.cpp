#include "LibraryCode.hpp"

double sqrtNum(double num){
    if(num<0){
        cout<<"exception thrown\n";
        throw std::runtime_error("Negative Num Pass!");
    }
    cout<<"No exception thrown\n";
    return sqrt(num);
}

int checkEven(int num){
    if(num&1){
        throw "input Even num!!";
    }
    return num; 
}

int checkOdd(int num){
    if(num&1){
        throw invalid_argument("input Odd num!!");
    }
    return num; 
}