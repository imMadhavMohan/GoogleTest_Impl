#include "LibraryCode.hpp"

InsuranceAge::InsuranceAge(){
    cout<<"Constructor called\n";
}

void InsuranceAge::setAge(int age){
    this->age = age;
}

bool InsuranceAge::validateAge(){
    return (age>18 && age<35)?1:0;
}

int InsuranceAge::getAge(){
    return age;
}