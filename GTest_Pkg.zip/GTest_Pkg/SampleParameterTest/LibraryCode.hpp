#pragma once
#include <algorithm>
#include <vector>
#include <iostream>
#include <math.h>
#include <stdexcept>

using namespace std;

class InsuranceAge {
public:    
    InsuranceAge();
    
    void setAge(int age);

    int getAge();

    bool validateAge();
private:
    int age;
};