#include "LibraryCode.hpp"
#include <gtest/gtest.h>

class AgeValidTestFixure: public ::testing::TestWithParam<int>{
    protected:
        InsuranceAge* mAge = new InsuranceAge();
        AgeValidTestFixure(){
            cout<<"AgeValidTestFixure constru\n";
        }
        void SetUp() override{ 
            cout<<"SetUp is Ready\n";            
        }
        void TearDown() override{
            cout<<"CleanUp is done Ready\n";    
        }
        ~AgeValidTestFixure(){
            cout<<"AgeValidTestFixure Destru\n";
        }
};

// unitTest-1 
TEST_P(AgeValidTestFixure, AgeRange){
       mAge->setAge(GetParam());
       int age = mAge->getAge();
       ASSERT_TRUE(mAge->validateAge());
}

// Set of 6 test cases
INSTANTIATE_TEST_SUITE_P(AddTestCases, AgeValidTestFixure, testing::Values(19,37,22,25,67,40));

// unitTest-2
// TEST(AdvCalculatorTest, Logtest1){
//     AdvCalculator* AdvCal = new AdvCalculator(1000);
//     ASSERT_EQ(AdvCal->findLoge(), 3);
// }

int main(int argc ,  char** argv){
    testing::InitGoogleTest(&argc, argv);
    cout<<"TestRunner Triggers: \n";
    return RUN_ALL_TESTS();
}